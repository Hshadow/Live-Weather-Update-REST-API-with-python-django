import requests

def getWeather(city_name):
    api = "58969000342f2d543fb69555f683853f"
    url = f"http://api.weatherstack.com/current?access_key={api}&query={city_name}"
    rs = requests.get(url)
    data = rs.json()
    return data

def getData(raw_data):
    name = raw_data['location']['name']
    region = raw_data['location']['region']
    country = raw_data['location']['country']
    location = f'{name}, {region}, {country}'

    lat = raw_data['location']['lat']
    lon = raw_data['location']['lon']
    lat_lon = f'{lat},{lon}'

    timezone_id = raw_data['location']['timezone_id']

    localtime = raw_data['location']['localtime']

    utc_offset = raw_data['location']['utc_offset']

    observation_time = raw_data['current']['observation_time']

    temperature = raw_data['current']['temperature']

    weather_icons = raw_data['current']['weather_icons']

    weather_descriptions = raw_data['current']['weather_descriptions']

    wind_speed = raw_data['current']['wind_speed']

    wind_degree = raw_data['current']['wind_degree']

    wind_dir = raw_data['current']['wind_dir']

    pressure = raw_data['current']['pressure']

    humidity = raw_data['current']['humidity']

    cloudcover = raw_data['current']['cloudcover']

    feelslike = raw_data['current']['feelslike']

    uv_index = raw_data['current']['uv_index']

    visibility = raw_data['current']['visibility']

    data = {
            'city':location, 'lat_lon':lat_lon, 'timezone_id':timezone_id, 'localtime':localtime, "utc_offset":utc_offset,
            'observation_time':observation_time, 'temperature':temperature, 'weather_icons':weather_icons, 
            'weather_descriptions':weather_descriptions, 'wind_speed':wind_speed, 'wind_degree':wind_degree, 
            'wind_dir':wind_dir, 'pressure':pressure, 'humidity':humidity, 'cloudcover':cloudcover, 'feelslike':feelslike,
            'uv_index':uv_index, 'visibility':visibility
            }

    return data


if __name__ == "__main__":
    raw_data = getWeather('alwar')
    print(getData(raw_data))

'''
{
    'request':
    {
        'type': 'City', 'query': 'Alwar, India', 'language': 'en', 'unit': 'm'
    },
    'location':
    {
        'name': 'Alwar', 'country': 'India', 'region': 'Rajasthan', 'lat': '27.567', 'lon': '76.600', 'timezone_id': 'Asia/Kolkata', 'localtime': '2020-09-06 17:43', 'localtime_epoch': 1599414180, 'utc_offset': '5.50'
    },
    'current':
    {
        'observation_time': '12:13 PM', 'temperature': 28, 'weather_code': 116, 'weather_icons': ['https://assets.weatherstack.com/images/wsymbols01_png_64/wsymbol_0002_sunny_intervals.png'], 'weather_descriptions': ['Partly cloudy'], 'wind_speed': 27, 'wind_degree': 275, 'wind_dir': 'W', 'pressure': 1000, 'precip': 0, 'humidity': 78, 'cloudcover': 30, 'feelslike': 32, 'uv_index': 7, 'visibility': 10, 'is_day': 'yes'
    }
}
'''
