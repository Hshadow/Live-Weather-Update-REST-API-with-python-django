from django.shortcuts import render
from django.http import HttpResponse
import pandas as pd
from Weather import weather as wt

def index(request):
    #params = {"city":city_names}
    if request.method == "POST":
        city_name = request.POST.get('city_name')
        data = wt.getData(wt.getWeather(city_name))
        params = {'display':True, 'data':data}
        return render(request, 'index.html', params)
    return render(request, 'index.html')#, params)

def weather(request):
    city_name = request.POST.get('city_name')
    data = wt.getData(wt.getWeather(city_name))
    params = {'display':True, 'data':data}
    return render(request, 'index.html', params)
